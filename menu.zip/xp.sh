#!/bin/bash
sudo sync
sudo echo 1 > /proc/sys/vm/drop_caches
sudo sync
sudo echo 2 > /proc/sys/vm/drop_caches
sudo sync
sudo echo 3 > /proc/sys/vm/drop_caches
clear
data=( `cat /etc/xray/xray.json | grep '^####' | cut -d ' ' -f 2 | sort | uniq`);
now=`date +"%Y-%m-%d"`
for user in "${data[@]}"
do
exp=$(grep -w "^#### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
d1=$(date -d "$exp" +%s)
d2=$(date -d "$now" +%s)
exp2=$(( (d1 - d2) / 86400 ))
if [[ "$exp2" -le "0" ]]; then
sed -i "/^#### $user $exp/,/^},{/d" /etc/xray/xray.json
sed -i "/^#### $user $exp/,/^},{/d" /etc/xray/xray.json
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
rm -rf /var/www/html/$user
rm -rf /etc/funny/limit/quota/$user
rm -rf /etc/funny/limit/ip/$user
rm -fr /etc/funny/limit/xray/ip/$user
rm -fr /etc/funny/limit/xray/quota/$user
telegram-send --pre "
Detail Account V2Ray Expired
=========================
Username: $user
Tanggal Exp: $exp
========================="
fi
done
clear
systemctl daemon-reload
systemctl restart xray v2ray
clear
