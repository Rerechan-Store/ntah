#!/bin/bash
# Informasi System
domain=$(cat /etc/xray/domain)
OS5=$(uname -o )
OS1=$(lsb_release -sd)
f1=$(lsb_release -sc)
clear
# Warna
red='\e[1;31m'
green='\e[0;32m'
cyan='\e[0;36m'
white='\e[037;1m'
grey='\e[1;36m'
NC='\e[0m'
clear
# Informasi Status Layanan Xray
revi=$(systemctl status xray | grep running | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [ "$revi" = "running" ]; then
vn2="${green}ON${NC}"
else
vn2="${red}OFF${NC}"
fi
# Informasi Status Layanan V2rayFly
vnd=$(systemctl status v2ray | grep running | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [ "$vnd" = "running" ]; then
xr="${green}ON${NC}"
else
xr="${red}OFF${NC}"
fi
# Informasi Status Layanan Loadbalance
hap=$(systemctl status nginx | grep running | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
if [ "$hap" = "running" ]; then
reha="${green}ON${NC}"
else
reha="${red}OFF${NC}"
fi

clear

add-ss() {
clear
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
echo -e "
============================
 Create ShadowSocks Account
============================"
read -p "Username         : " user
read -p "Quota (GB)       : " quota
read -p "Max Ip login     : " iplimit
read -p "Masaaktif        : " masaaktif
CLIENT_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
echo -e "
Udah Ada Akunya"
fi
done
#QUOTA
if [[ $quota -gt 0 ]]; then
echo -e "$[$quota * 1024 * 1024 * 1024]" > /etc/funny/limit/xray/quota/$user
else
echo > /dev/null
fi

#IPLIMIT
if [[ $iplimit -gt 0 ]]; then
echo -e "$iplimit" > /etc/funny/limit/xray/ip/$user
else
echo > /dev/null
fi
cipher="aes-128-gcm"
pwss=$(echo $RANDOM | md5sum | head -c 6; echo;)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#ss$/a\#### '"$user $exp"'\
},{"password": "'""$pwss""'","method": "'""$cipher""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#ss-grpc$/a\#### '"$user $exp"'\
},{"password": "'""$pwss""'","method": "'""$cipher""'","email": "'""$user""'"' /etc/xray/xray.json
echo -n "$cipher:$pwss" | base64 -w 0 > /tmp/log
ss_base64=$(cat /tmp/log)
shadowsockslink1="ss://${ss_base64}@$domain:443?path=/ss&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
shadowsockslink2="ss://${ss_base64}@$domain:80?path=/ss&security=none&host=${domain}&type=ws#${user}"
shadowsockslink3="ss://${ss_base64}@$domain:443?security=tls&encryption=none&type=grpc&serviceName=ss-grpc&sni=$domain#${user}"
rm -rf /tmp/log
systemctl restart xray
systemctl restart v2ray
clear
TEKS="
============================
   [ ShadowSock Account ]
============================
Username   : ${user}
Domain     : $domain
wildcard   : bug.com.${domain}
Password   : $pwss
Expired    : $exp
============================
Limit IP   : $iplimit Device
Limit Quota: $quota GB
============================
Port TLS   : 443
Port NTLS  : 80
Cipher     : ${cipher}
Network    : Websocket, gRPC
Path       : /ss
ServiceName: ss-grpc
Alpn       : h2, http/1.1
============================
Link TLS : ${shadowsockslink1}
============================
Link NTLS: ${shadowsockslink2}
============================
Link gRPC: ${shadowsockslink3}
============================"
telegram-send --pre "$TEKS"
clear
echo -e "$TEKS"
}

add-2022() {
clear
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
clear
read -p "Username         : " user
read -p "Quota (GB)       : " quota
read -p "Max Ip login     : " iplimit
read -p "Masaaktif        : " masaaktif
CLIENT_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
echo -e "
Udah Ada Akunya"
fi
done
#QUOTA
if [[ $quota -gt 0 ]]; then
echo -e "$[$quota * 1024 * 1024 * 1024]" > /etc/funny/limit/xray/quota/$user
else
echo > /dev/null
fi

#IPLIMIT
if [[ $iplimit -gt 0 ]]; then
echo -e "$iplimit" > /etc/funny/limit/xray/ip/$user
else
echo > /dev/null
fi
cipher2="2022-blake3-aes-128-gcm"
userpsk=$(openssl rand -base64 16)
serverpsk=$(cat /etc/xray/serverpsk)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#ss2022$/a\#### '"$user $exp"'\
},{"password": "'""$userpsk""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#ss2022-grpc$/a\#### '"$user $exp"'\
},{"password": "'""$userpsk""'","email": "'""$user""'"' /etc/xray/xray.json
echo -n "$cipher2:$serverpsk:$userpsk" | base64 -w 0 > /tmp/log
ss2022_base64=$(cat /tmp/log)
ss2022link1="ss://${ss2022_base64}@$domain:443?path=/ss2022&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
ss2022link2="ss://${ss2022_base64}@$domain:80?path=/ss2022&security=none&host=${domain}&type=ws#${user}"
ss2022link3="ss://${ss2022_base64}@$domain:443?security=tls&encryption=none&type=grpc&serviceName=ss2022-grpc&sni=$domain#${user}"
rm -rf /tmp/log
systemctl restart xray
systemctl restart v2ray
clear
TEKS="
============================
[ Shadowsocks 2022 Account ]
============================
Username  : ${user}
Password  : $serverpsk:$userpsk
Domain    : $domain
wildcard  : bug.com.${domain}
Expired   : $exp
============================
Limit IP   : $iplimit Device
Limit Quota: $quota GB
============================
Port TLS  : 443
Port NTLS : 80
Network   : Websocket, gRPC
Path      : /ss2022
Path gRPC : ss2022-grpc
Alpn      : h2, http/1.1
============================
Link TLS  : ${ss2022link1}
============================
Link NTLS : ${ss2022link1}
============================
Link gRPC : ${ss2022link1}
============================"
telegram-send --pre "$TEKS"
clear
echo -e "$TEKS"
}

add-trojan() {
clear
domain=$(cat /etc/xray/domain)
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${user_EXISTS} == '0' ]]; do
read -p "Username         : " user
read -p "Quota (GB)       : " quota
read -p "Max Ip login     : " iplimit
read -p "Masaaktif        : " masaaktif
user_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${user_EXISTS} == '1' ]]; then
clear
echo -e "
Udah Ada Akunya"
fi
done
#QUOTA
if [[ $quota -gt 0 ]]; then
echo -e "$[$quota * 1024 * 1024 * 1024]" > /etc/funny/limit/xray/quota/$user
else
echo > /dev/null
fi

#IPLIMIT
if [[ $iplimit -gt 0 ]]; then
echo -e "$iplimit" > /etc/funny/limit/xray/ip/$user
else
echo > /dev/null
fi
# uuid=$(cat /proc/sys/kernel/random/uuid)
pwtr=$(openssl rand -hex 4)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#trojan$/a\#### '"$user $exp"'\
},{"password": "'""$pwtr""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#trojan-tcp$/a\#### '"$user $exp"'\
},{"password": "'""$pwtr""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#trojan-grpc$/a\#### '"$user $exp"'\
},{"password": "'""$pwtr""'","email": "'""$user""'"' /etc/xray/xray.json
trojanlink1="trojan://$pwtr@$domain:443?path=/trojan&security=tls&host=$domain&type=ws&sni=$domain#$user"
trojanlink2="trojan://${pwtr}@$domain:80?path=/trojan&security=none&host=$domain&type=ws#$user"
trojanlink3="trojan://${pwtr}@$domain:443?security=tls&encryption=none&type=grpc&serviceName=grpc-trojan&sni=$domain#$user"
trojanlink4="trojan://${pwtr}@$domain:443?security=tls&type=tcp&sni=$domain#$user"
systemctl restart xray
systemctl restart v2ray
clear
TEKS="
==========================
[ <=  Trojan Account  => ]
==========================
Username   : ${user}
Password   : ${pwtr}
Domain     : $domain
Wildcard   : bug.com.${domain}
Expired    : $exp
============================
Limit IP   : $iplimit Device
Limit Quota: $quota GB
============================
Port TLS   : 443
Port TCP   : 443
Port gRPC  : 443
Port NTLS  : 80
Network    : TCP, WS, gRPC
Path       : /trojan
ServiceName: grpc-trojan
Alpn       : h2, http/1.1
==========================
Link TLS  : ${trojanlink1}
==========================
Link NTLS : ${trojanlink2}
==========================
Link gRPC : ${trojanlink3}
==========================
Link TCP  : ${trojanlink4}
=========================="
telegram-send --pre "$TEKS"
clear
echo -e "$TEKS"
}

add-vless() {
clear
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
clear
read -p "Username         : " user
read -p "Quota (GB)       : " quota
read -p "Max Ip login     : " iplimit
read -p "Masaaktif        : " masaaktif
CLIENT_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
echo -e "Username Sudah Ada"
fi
done
#QUOTA
if [[ $quota -gt 0 ]]; then
echo -e "$[$quota * 1024 * 1024 * 1024]" > /etc/funny/limit/xray/quota/$user
else
echo > /dev/null
fi

#IPLIMIT
if [[ $iplimit -gt 0 ]]; then
echo -e "$iplimit" > /etc/funny/limit/xray/ip/$user
else
echo > /dev/null
fi
uuid=$(cat /proc/sys/kernel/random/uuid)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#universal/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vless$/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vless-grpc$/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vless-xtls$/a\#&@ '"$user $exp"'\
},{"flow": "'""xtls-rprx-vision""'","id": "'""$uuid""'","email": "'""$user""'"' /etc/xray/xray.json
vlesslink1="vless://$uuid@$domain:443?path=/vless&security=tls&encryption=none&host=$domain&type=ws&sni=$domain#$user"
vlesslink2="vless://$uuid@$domain:80?path=/vless&security=none&encryption=none&host=$domain&type=ws#$user"
vlesslink3="vless://$uuid@$domain:443?security=tls&encryption=none&type=grpc&serviceName=grpc-vless&sni=$domain#$user"
vlesslink4="vless://$uuid@$domain:443?security=tls&encryption=none&headerType=none&type=tcp&sni=$domain&flow=xtls-rprx-vision&fp=chrome#$user"
systemctl restart xray
systemctl restart v2ray
clear
TEKS="
===========================
[<= V2ray Vless Account =>]
===========================
Username   : ${user}
Password   : ${uuid}
Domain     : $domain
Wildcard   : bug.com.${domain}
Expired    : $exp
============================
Limit IP   : $iplimit Device
Limit Quota: $quota GB
============================
Port TLS   : 443
Port XTLS  : 443
Port gRPC  : 443
Port NTLS  : 80
Network    : XTLS, WS, gRPC
Flow       : xtls-rpx-vision
Path       : /vless
ServiceName: grpc-vless
Alpn       : h2, http/1.1
===========================
Link TLS  : ${vlesslink1}
===========================
Link NTLS : ${vlesslink2}
===========================
Link gRPC : ${vlesslink3}
===========================
Link XTLS : ${vlesslink4}
==========================="
telegram-send --pre "$TEKS"
clear
echo -e "$TEKS"
}
add-socks() {
clear
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
echo -e "
============================
 Create Socks5 Account
============================"
read -p "Username         : " user
read -p "Password         : " pass
read -p "Masaaktif        : " masaaktif
CLIENT_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
echo -e "
Udah Ada Akunya"
fi
done
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#socks5$/a\#### '"$user $exp"'\
},{"user": "'""$user""'","pass": "'""$pass""'","email": "'""$user""'"' /etc/xray/xray.json
echo -n "$user:$pass" | base64 > /tmp/log
socks_base64=$(cat /tmp/log)
hts="socks://$socks_base64@$domain:443?path=/socks5&security=tls&host=$domain&type=ws&sni=$domain#$user"
htp="socks://$socks_base64@$domain:80?path=/socks5&security=none&host=$domain&type=ws#$user"
gcp="socks://$socks_base64@$domain:443?security=tls&encryption=none&type=grpc&serviceName=socks5-grpc&sni=$domain#$user"
rm -rf /tmp/log
systemctl daemon-reload
systemctl restart v2ray
clear
TEKS="
==============================
[ <= V2ray Socks5 Account => ]
==============================

Domain   : $domain
wildcard : bug.com.${domain}
Username : $user
Password : $pass
Expired  : $exp
==============================
Port TLS & gRPC    : 443
Port WS HTTP       : 80
Network            : WS & gRPC
Alpn               : h2, http/1.1
Path & Service Name: /socks5 & socks5-grpc
==============================
Link HTTPS : $hts
==============================
Link HTTP  : $htp
==============================
Link gRPC  : $gcp
=============================="
telegram-send --pre "$TEKS"
clear
echo -e "
$TEKS
"
}

add-vmess() {
clear
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
clear
read -p "Username         : " user
read -p "Quota (GB)       : " quota
read -p "Max Ip login     : " iplimit
read -p "Masaaktif        : " masaaktif
CLIENT_EXISTS=$(grep -w $user /etc/xray/xray.json | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
clear
echo -e " Account Already"
fi
done
#QUOTA
if [[ $quota -gt 0 ]]; then
echo -e "$[$quota * 1024 * 1024 * 1024]" > /etc/funny/limit/xray/quota/$user
else
echo > /dev/null
fi

#IPLIMIT
if [[ $iplimit -gt 0 ]]; then
echo -e "$iplimit" > /etc/funny/limit/xray/ip/$user
else
echo > /dev/null
fi
uuid=$(cat /proc/sys/kernel/random/uuid)
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#universal$/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vmess$/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vmess-grpc$/a\#### '"$user $exp"'\
},{"id": "'""$uuid""'","alterId": '"0"',"email": "'""$user""'"' /etc/xray/xray.json
sed -i '/#vmess$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'","alterid": '"0"',"email": "'""$user""'"' /etc/xray/config.json
vlink1=`cat << EOF
{
"v": "2",
"ps": "$user",
"add": "$domain",
"port": "443",
"id": "$uuid",
"aid": "0",
"net": "ws",
"path": "/vmesswss",
"type": "none",
"host": "$domain",
"tls": "tls"
}
EOF`
vlink2=`cat << EOF
{
"v": "2",
"ps": "$user",
"add": "$domain",
"port": "80",
"id": "$uuid",
"aid": "0",
"net": "ws",
"path": "/vmesswss",
"type": "none",
"host": "$domain",
"tls": "none"
}
EOF`
vlink3=`cat << EOF
{
"v": "2",
"ps": "$user",
"add": "$domain",
"port": "443",
"id": "$uuid",
"aid": "0",
"net": "grpc",
"path": "grpc-vmess",
"type": "none",
"host": "$domain",
"tls": "tls"
}
EOF`
vlink4=`cat << EOF
{
"v": "2",
"ps": "$user",
"add": "$domain",
"port": "8080",
"id": "$uuid",
"aid": "0",
"net": "ws",
"path": "whatever",
"type": "none",
"host": "$domain",
"tls": "none"
}
EOF`
vmesslink1="vmess://$(echo $vlink1 | base64 -w 0)"
vmesslink2="vmess://$(echo $vlink2 | base64 -w 0)"
vmesslink3="vmess://$(echo $vlink3 | base64 -w 0)"
vmesslink4="vmess://$(echo $vlink4 | base64 -w 0)"
systemctl restart xray
systemctl restart v2ray
clear
TEKS="
===========================
[<= V2ray Vmess Account =>]
===========================
Username   : ${user}
Password   : ${uuid}
Domain     : $domain
Wildcard   : bug.com.${domain}
Expired    : $exp
============================
Limit IP   : $iplimit Device
Limit Quota: $quota GB
============================
Port TLS   : 443
Port NTLS  : 80
Port gRPC  : 443
Custom Path: 8080
Network    : Ws, gRPC
Path       : /vmesswss
Dynamic    : /whatever or whatever ( Example: /worryfree & /kuota-habis )
ServiceName: grpc-vmess
Alpn       : h2, http/1.1
===========================
Link TLS   : $vmesslink1
===========================
Link NTLS  : $vmesslink2
===========================
Link gRPC  : $vmesslink3
===========================
Link Custom: $vmesslink4
==========================="
telegram-send --pre "$TEKS"
clear
echo -e "$TEKS"
}

cekv() {
df='\e[39m'
bold='\e[1m'
blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
purple='\e[35m'
cyan='\e[36m'
lred='\e[91m'
lgreen='\e[92m'
lyellow='\e[93m'
nc='\e[0m'
green='\033[0;32m'
orange='\033[0;33m'
light='\033[0;37m'
grenbo="\e[92;1m"
clear
function con() {
local -i bytes=$1;
if [[ $bytes -lt 1024 ]]; then
echo "${bytes}b"
elif [[ $bytes -lt 1048576 ]]; then
echo "$(( (bytes + 1023)/1024 ))kb"
elif [[ $bytes -lt 1073741824 ]]; then
echo "$(( (bytes + 1048575)/1048576 ))mb"
else
echo "$(( (bytes + 1073741823)/1073741824 ))gb"
fi
}
echo -n > /tmp/other.txt
data=( `cat /etc/xray/xray.json | grep '####' | cut -d ' ' -f 2 | sort | uniq`);
clear
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e " \e[1;97;101m           cek v2ray account            \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e "\033[1;36m└─────────────────────────────────────────┐\033[0m"
for akun in "${data[@]}"
do
if [[ -z "$akun" ]]; then
akun="tidakada"
fi
echo -n > /tmp/ipvmess.txt
data2=( `cat /var/log/xray/akses.log | tail -n 500 | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq`);
for ip in "${data2[@]}"
do
jum=$(cat /var/log/xray/akses.log | grep -w "$akun" | tail -n 500 | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | grep -w "$ip" | sort | uniq)
if [[ "$jum" = "$ip" ]]; then
echo "$jum" >> /tmp/ipvmess.txt
else
echo "$ip" >> /tmp/other.txt
fi
jum2=$(cat /tmp/ipvmess.txt)
sed -i "/$jum2/d" /tmp/other.txt > /dev/null 2>&1
done
jum=$(cat /tmp/ipvmess.txt)
if [[ -z "$jum" ]]; then
echo > /dev/null
else
jum2=$(cat /tmp/ipvmess.txt | wc -l)
lastlogin=$(cat /var/log/xray/akses.log | grep -w "$akun" | tail -n 500 | cut -d " " -f 2 | tail -1)
log1=$(cat /var/log/xray/akses.log | grep -w "$akun" | tail -n 500 | cut -d " " -f 5 | tail -1)
printf "  %-13s %-7s %-8s %2s\n" "username   : ${akun}"
printf "  %-13s %-7s %-8s %2s\n" "jumlah ip  : $jum2"
printf "  %-13s %-7s %-8s %2s\n" "last login : $lastlogin"
printf "  %-13s %-7s %-8s %2s\n" "Akses Web  : $log1";
echo -e "\033[1;36m┌─────────────────────────────────────────┘\033[0m"
fi
rm -rf /tmp/ipvmess.txt
done
rm -rf /tmp/other.txt
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e "\e[1;97;101m         done cek v2ray account           \e[0m"
echo -e "\033[1;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
}
mx() {
touch /root/.system
clear
echo -e "\033[1;36m┌─────────────────────────────────────────┐\033[0m" | lolcat
echo -e "        =[ member v2ray account ]=         "
echo -e "\033[1;36m└─────────────────────────────────────────┐\033[0m" | lolcat
echo -n > /root/.accsess.log
data=( $(cat /etc/xray/xray.json | grep '####' | cut -d ' ' -f 2 | sort | uniq) )
for user in "${data[@]}"
do
echo > /dev/null
jum=$(cat /etc/xray/xray.json | grep -c '####' | awk '{print $1/2}')
if [[ $jum -gt 0 ]]; then
exp=$(grep -wE "^### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
echo -e "  \e[33;1mUser\e[32;1m  : $user"
echo -e "  \e[33;1mExp\e[32;1m   : $exp"
echo -e "\033[1;36m┌─────────────────────────────────────────┘\033[0m" | lolcat
echo "slot" >> /root/.system
else
echo > /dev/null
fi
sleep 0.1
done
aktif=$(cat /root/.system | wc -l)
echo -e "\033[1;36m┌─────────────────────────────────────────┐\033[0m" | lolcat
echo -e "   $aktif Member Active"
echo -e "\033[1;36m└─────────────────────────────────────────┘\033[0m" | lolcat
sed -i "d" /root/.system
}

delv() {
NC='\e[0m'
DEFBOLD='\e[39;1m'
RB='\e[31;1m'
GB='\e[32;1m'
YB='\e[33;1m'
BB='\e[34;1m'
MB='\e[35;1m'
CB='\e[35;1m'
WB='\e[37;1m'
clear
NUMBER_OF_CLIENTS=$(grep -c -E "^#### " "/etc/xray/xray.json")
if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
clear
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "                ${WB}Delete Vmess Account${NC}                "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "  ${YB}You have no existing clients!${NC}"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
read -n 1 -s -r -p "Press any key to back on menu"
delv
fi
clear
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "                ${WB}Delete Vmess Account${NC}                "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e " ${YB}User  Expired${NC}  "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
grep -E "^#### " "/etc/xray/xray.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq
echo ""
echo -e "${YB}tap enter to go back${NC}"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
read -rp "Input Username : " user
if [ -z $user ]; then
delv
else
exp=$(grep -wE "^#### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#### $user $exp/,/^},{/d" /etc/xray/xray.json
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
rm -fr /etc/funny/limit/xray/quota/$user
rm -fr /etc/funny/limit/xray/ip/$user
systemctl restart xray
systemctl restart v2ray
clear
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "           ${WB}Vmess Account Success Deleted${NC}            "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e " ${YB}Client Name :${NC} $user"
echo -e " ${YB}Expired On  :${NC} $exp"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
clear
menu
fi
}

renewv() {
NC='\e[0m'
DEFBOLD='\e[39;1m'
RB='\e[31;1m'
GB='\e[32;1m'
YB='\e[33;1m'
BB='\e[34;1m'
MB='\e[35;1m'
CB='\e[35;1m'
WB='\e[37;1m'
clear
NUMBER_OF_CLIENTS=$(grep -c -E "^#### " "/etc/xray/xray.json")
if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "                ${WB}Extend V2ray Account${NC}               "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "  ${YB}You have no existing clients!${NC}"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
menu
fi
clear
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "                ${WB}Extend V2ray Account${NC}               "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e " ${YB}User  Expired${NC}  "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
grep -E "^#### " "/etc/xray/xray.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq
echo ""
echo -e "${YB}tap enter to go back${NC}"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
read -rp "Input Username : " user
if [ -z $user ]; then
menu
else
read -p "Expired (days): " masaaktif
exp=$(grep -wE "^#### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
now=$(date +%Y-%m-%d)
d1=$(date -d "$exp" +%s)
d2=$(date -d "$now" +%s)
exp2=$(( (d1 - d2) / 86400 ))
exp3=$(($exp2 + $masaaktif))
exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
sed -i "/#### $user/c\#### $user $exp4" /etc/xray/xray.json
sed -i "/### $user/c\### $user $exp4" /etc/xray/config.json
systemctl restart xray
systemctl restart v2ray
clear
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e "           ${WB}V2ray Account Success Extended${NC}            "
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo -e " ${YB}Client Name :${NC} $user"
echo -e " ${YB}Expired On  :${NC} $exp4"
echo -e "${BB}————————————————————————————————————————————————————${NC}"
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
clear
menu
fi
}

bmenu() {
bmenu() {
#
#  |==========================================================|
#  • Autoscript AIO Lite Menu By Rerechan02
#  • FN Project Developer @Rerechan02 | @PR_Aiman | @xlordeuyy
#  • Copyright 2024 18 Marc Indonesia [ Kebumen ]
#  |==========================================================|
#
backup() {
date=$(date)
# // Test Backup
clear
echo "Mohon Menunggu , Proses Backup sedang berlangsung !!"
rm -rf /root/backup
mkdir /root/backup
cp -r /etc/xray backup/xray
cp -r /etc/funny backup/funny
cd /root
zip -r backup.zip backup > /dev/null 2>&1
# // Selesai Melakukan Backup
clear
# // Melakukan Generate Link
#token="JOXRV3O.8YTMGEH-JSC4VTS-N7PAHNV-FHM3X2P"
num_digits=6
random_number=$(shuf -i 100000-999999 -n 1)
file_path="/root/backup.zip"
api_url="https://file.io"
expiry_duration=$((14 * 24 * 60 * 60))
response=$(curl -s -F "file=@$file_path" -F "expiry=$expiry_duration" $api_url)
upload_link=$(echo $response | jq -r .link)
telegram-send --file backup.zip --caption "${date}"
clear
echo "
[ Information Your Backup Data ]
================================

Your ID    : $random_number
Link Backup: $upload_link
================================
"
echo " Please Save your Link Backup "
rm -fr /root/backup*
}

rest() {
clear
echo "This Feature Can Only Be Used According To Vps Data With This Autoscript"
echo "Please input link to your vps data backup file."
read -rp "Link File: " -e url
cd /root
wget -O backup.zip "$url"
unzip backup.zip
rm -f backup.zip
sleep 1
echo "Tengah Melakukan Backup Data"
cd /root/backup
cp -r xray /etc/
cp -r funny /etc/
clear
rm -rf /root/backup
rm -f backup.zip
clear
echo "Telah Berjaya Melakukan Backup"
}

restf() {
cd /root
file="backup.zip"
if [ -f "$file" ]; then
echo "$file ditemukan, melanjutkan proses..."
sleep 2
clear
unzip backup.zip
rm -f backup.zip
sleep 1
echo "Tengah Melakukan Backup Data"
cd /root/backup
cp passwd /etc/
cp group /etc/
cp shadow /etc/
cp gshadow /etc/
cp -r xray /etc/
cp -r funny /etc/
clear
rm -rf /root/backup
rm -f backup.zip
clear
echo "Telah Berjaya Melakukan Backup"
else
    echo "Error: File $file Not Found"
fi
}

clear
sleep 1
if ! command -v telegram-send &> /dev/null; then
    echo "depen is not installed. Installing..."
    apt install python3 python3-pip -y
    pip3 install telegram-bot
    print "7157867705:AAE7s3jIg2G6cT6obaDbNVYu2v0nupqkpL8" | telegram-send --configure
fi

mna() {
clear
echo "
============================
Menu Backup Data VPN in VpS
============================

1. Backup Your Data VPN
2. Restore With Link Backup
3. Restore With SFTP / Termius
==============================
Press CTRL + C / X to Exit Menu
"
read -p "Input Valid Number Option: " mla
case $mla in
1) clear ; backup ;;
2) clear ; rest ;;
3) clear ; restf ;;
x) exit ;;
*) echo " Please Input Valid Number " ; mna ;;
esac
}

mna
}
}

dm-menu() {
cert() {
clear
echo -e "[ ${green}INFO${NC} ] Start " 
sleep 0.5
NC='\e[0m'
green='\033[0;92m'       # Green
systemctl stop nginx
systemctl stop haproxy
systemctl stop v2ray
domain=$(cat /etc/xray/domain)
rm -fr /etc/haproxy/funny.pem
rm -fr /etc/xray/xray.crt
rm -fr /etc/xray/xray.key
sleep 1
echo -e "[ ${red}WARNING${NC} ] Detected port 80 used by Nginx " 
sleep 2
echo -e "[ ${green}INFO${NC} ] Processing to stop V2ray " 
sleep 1
clear
echo -e "[ ${green}INFO${NC} ] Starting renew cert... " 
sleep 2
clear
/root/.acme.sh/acme.sh --set-default-ca --server letsencrypt
/root/.acme.sh/acme.sh --issue -d $domain --standalone -k ec-256
~/.acme.sh/acme.sh --installcert -d $domain --fullchainpath /etc/xray/xray.crt --keypath /etc/xray/xray.key --ecc
sleep 2
clear
echo -e "[ ${green}INFO${NC} ] Renew cert done... " 
sleep 2
clear
echo -e "[ ${green}INFO${NC} ] Starting service V2ray " 
sleep 2
echo $domain > /etc/xray/domain
cat /etc/xray/xray.crt /etc/xray/xray.key | tee /etc/haproxy/funny.pem
clear
systemctl restart nginx
systemctl restart haproxy
systemctl restart v2ray
clear
echo -e "[ ${green}INFO${NC} ] All finished... " 
clear
sleep 0.5
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
menu
}
add-domain() {
clear
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e "Domain anda saat ini:"
echo -e "$(cat /etc/xray/domain)"
echo ""
read -rp "Domain/Host: " -e host
echo ""
if [ -z $host ]; then
echo "DONE CHANGE DOMAIN"
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
read -n 1 -s -r -p "Press any key to back on menu"
menu
else
echo "$host" > /etc/xray/domain
echo -e "\e[33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
echo -e ""
read -n 1 -s -r -p "Press any key to renew cert"
cert
fi
}
clear
echo -e "${cyan}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e " \E[41;1;37m                  ◎ DOMAIN  MENU ◎                        \E[0m"
echo -e "${cyan}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e  "  "
echo -e "${white} [ 1 ] •${white} CHANGE SUBDOMAIN VPN"
echo -e "${white} [ 2 ] •${white} RENEW CERTIFICATE DOMAIN"
echo -e  "  "

echo -e  "    ${green}PRESS [ X ] TO EXIT MENU${NC} "
echo -e
echo -e "${cyan}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo -e " \E[41;1;37m               ◎ Modded By Rerechan02 ◎                   \E[0m"
echo -e "${cyan}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | lolcat
echo ""
read -p  " PLEASE SELECT AN OPTION : " Setbackuptime
echo -e "\e[0m"
case $Setbackuptime in
        1)
        clear
        add-domain
        ;;
        2)
        clear
        cert
        ;;
        x)
    exit
    ;;
        *)
        echo -e "Please enter an correct number"
        sleep 1
        clear
        dm-menu
        ;;
        esac
}

menu() {
clear
echo -e "
=========================
Autoscript AIO X-Ray『𝐅𝐍』
=========================
"
echo -e "\e[037;1m Operating System:${green} $OS5 / $OS1 ${white}[${green} $f1 ${white}]"
echo -e "\e[037;1m DOMAIN:${green} $domain ${white}"
echo -e "
=========================
   [ Status Layanan ]

V2RayFly  : $vn2
Apache2   : $xr
SERVER    : $reha
=========================
     [ Menu Layanan ]

01. Create Shadowsocks
02. Create Shadowsocks 2022
03. Create V2ray Trojan
04. Create V2ray Vless
05. Create V2ray Vmess
06. Create V2ray Socks5
07. Cek User Login V2ray
08. Delete Account V2ray
09. Renew Account V2ray
==========================
       [ Other Meu ]

10. Backup & Restore Menu
11. Change Domain & Renew Cert
12. Cek Usage CPU & Ram Your Server
==========================
Press CTRL + C or X to Exit
==========================
"
read -p "Input Option: " opt
case $opt in
01|1) clear ; add-ss ;;
02|2) clear ; add-2022 ;;
03|3) clear ; add-trojan ;;
04|4) clear ; add-vless ;;
05|5) clear ; add-vmess ;;
06|6) clear ; add-socks ;;
07|7) clear ; cekv ;;
08|8) clear ; delv ;;
09|9) clear ; renewv ;;
10) bmenu ;;
11) dm-menu ;;
12) htop ;;
x|X) exit ;;
*) clear ; menu ;;
esac
}
menu
