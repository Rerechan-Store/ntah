#!/bin/bash
mkdir -p /etc/funny/limit/xray/quota
  while true; do
  sleep 30
  data=($(cat /etc/xray/xray.json | grep '^####' | cut -d ' ' -f 2 | sort | uniq))
  if [[ ! -e /etc/funny/limit/xray/quota ]]; then
  mkdir -p /etc/funny/limit/xray/quota
  fi
  for user in ${data[@]}
  do
  xray api stats --server=127.0.0.1:62789 -name "user>>>${user}>>>traffic>>>downlink" >& /tmp/${user}
  getThis=$(cat /tmp/${user} | awk '{print $1}');
  if [[ ${getThis} != "failed" ]]; then
        downlink=$(xray api stats --server=127.0.0.1:62789 -name "user>>>${user}>>>traffic>>>downlink" | grep -w "value" | awk '{print $2}' | cut -d '"' -f2);
        if [ -e /etc/funny/limit/xray/quota/${user} ]; then
        plus2=$(cat /etc/funny/limit/xray/quota/${user});
        if [[ ${#plus2} -gt 0 ]]; then
        plus3=$(( ${downlink} + ${plus2} ));
        echo "${plus3}" > /etc/funny/limit/xray/quota/"${user}"
        xray api stats --server=127.0.0.1:62789 -name "user>>>${user}>>>traffic>>>downlink" -reset > /dev/null 2>&1
        else
        echo "${downlink}" > /etc/funny/limit/xray/quota/"${user}"
        xray api stats --server=127.0.0.1:62789 -name "user>>>${user}>>>traffic>>>downlink" -reset > /dev/null 2>&1
        fi
        else
        echo "${downlink}" > /etc/funny/limit/xray/quota/"${user}"
        xray api stats --server=127.0.0.1:62789 -name "user>>>${user}>>>traffic>>>downlink" -reset > /dev/null 2>&1
        fi
        else
      echo ""
   fi
done
# Check ur Account
for user in ${data[@]}
  do
    if [ -e /etc/funny/limit/xray/quota/${user} ]; then
      checkLimit=$(cat /etc/funny/limit/xray/quota/${user});
      if [[ ${#checkLimit} -gt 1 ]]; then
      if [ -e /etc/funny/limit/xray/quota/${user} ]; then
      Usage=$(cat /etc/funny/limit/xray/quota/${user});
      if [[ ${Usage} -gt ${checkLimit} ]]; then
      exp=$(grep -w "^#### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
      sed -i "/^#### $user $exp/,/^},{/d" /etc/xray/xray.json
      sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
      rm -fr /etc/funny/limit/xray/quota/${user}
      rm -fr /etc/funny/limit/xray/ip/${user}
      rm -fr /var/www/html/${user}
      systemctl restart v2ray xray >> /dev/null 2>&1
      else
      echo ""
      fi
      else
      echo ""
      fi
      else
      echo ""
      fi
      else
      echo ""
    fi
  done
done
clear
