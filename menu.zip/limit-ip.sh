#!/bin/bash
mkdir -p /etc/funny/limit/xray/ip
echo -n > /var/log/xray/akses.log
sleep 4
data=( `ls /etc/funny/limit/xray/ip`);
for user in "${data[@]}"
do
iplimit=$(cat /etc/funny/limit/xray/ip/$user)
ehh=$(cat /var/log/xray/akses.log | grep "$user" | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq);
cekcek=$(echo -e "$ehh" | wc -l);
if [[ $cekcek -gt $iplimit ]]; then
exp=$(grep -w "^#### $user" "/etc/xray/xray.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#### $user $exp/,/^},{/d" /etc/xray/xray.json
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
rm -fr /etc/funny/limit/xray/quota/${user}
rm -fr /etc/funny/limit/xray/ip/${user}
rm -fr /var/www/html/${user}
systemctl restart v2ray >> /dev/null 2>&1
nais=3
else
echo > /dev/null
fi
sleep 0.1
done
if [[ $nais -gt 1 ]]; then
systemctl restart v2ray
else
echo > /dev/null
fi
